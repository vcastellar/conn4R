# conn4R
juego de IA para el conecta 4
